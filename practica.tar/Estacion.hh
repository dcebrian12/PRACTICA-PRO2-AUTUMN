/** @file Estacion.hh
    @brief Especificacion de la clase Estacion
*/

#ifndef ESTACION_HH
#define ESTACION_HH

#ifndef NO_DIAGRAM
#include <iostream>
#include <set>
using namespace std;
#endif

class Estacion
{
private:
    string id_estacion;
    int max_bicis;
    set<string> bicis_estacion;
    pair<int, int> plazas_nodos; // auxiliar para asignar estacion

public:
    // Constructores

    /** @brief Constructora vacia
     *  \pre Cierto.
     * \post Se crea una estacion con max_bicis = 0, identificador NP y sin bicis
     */
    Estacion();

    /** @brief Constructora por defecto
        \pre id no corresponde a una estacion, max es > 0
        \post Se crea una estacion con max_bicis = max y identificador id,
        los demas valores sdel p.i. son vacios
    */
    Estacion(int max, const string id);

    // Modificadores

    /** @brief Aumenta la capacidad maxima del p.i
     * \pre p.i inicializado, max_num es > 0 y >= que max bicis del p.i
     * \post Se actualiza el valor de max_bicis del p.i por por max_num
     */
    void modificar_capacidad_estacion(const int &max_num);

    /** @brief Añade la bici a la estacion
     * \pre id_bici corresponde a una bicicleta que no se encuentra en el p.i.
     * \post Se añade la bicicleta a la estacion
     */
    void afegir_bici(const string &id_bici);

    /** @brief Borra una bicicleta de la estacion
        \pre id_bici existe en el p.i.
        \post La bicicleta no es encuentra en el parametro implicito
    */
    void borrar_bici(const string &id_bici);

    /** @brief Modifica el numero de nodos y plazas libres a partir de la estacion
     *  \pre n y p son positivos
     *  \post Se modifica el numero de nodos y plazas libres del p.i.
     */
    void modifica_nodos_plazas(const int n, const double p);

    // Consultores

    /** @brief Sevuelve la bici con el id mas pequeño
     *  \pre Hay minimo una bicicleta en el p.i.
     * \post Devuelve la bici con el id mas pequeño
     */
    string idbici_menor() const;

    /** @brief Devuelve el numero de bicis que se encuentran en la estacion
     *  \pre Cierto.
     *  \post Devuelve el total de bicis del p.i.
     */
    int total_bicis() const;

    /** @brief Consulta si la estacion esta llena
        \pre:Cierto.
        \post: Devuelve true si la estacion esta llena, false si no lo esta
    */
    bool estacion_llena() const;

    /** @brief Consulta si la estacion esta vacia
        \pre:Cierto.
        \post: Devuelve true si la estacion esta vacia, false si no lo esta
    */
    bool estacion_vacia() const;

    /** @brief Consulta el identificador del parametro implicito
        \pre p.i. incializado
        \post Devuelve el identificador del parametro implicito
    */
    string identificador_estacion() const;

    /** @brief Consulta el tamaño maximo del parametro implicito
        \pre El parametro implicito esta inicializado
        \post Devuelve el maximo de bicicletas del parametro implicito
    */
    int max_estacion() const;

    pair<int, int> consultar_nodos_plazas() const;

    // Lectura y escritura

    /** @brief Imprime el id de las bicis en estacion
     *  \pre El p.i. esta inicializado
     *  \post Se muestra por pantalla las bicis que hay en estacion por orden alfabetico
     */
    void bicis_en_estacion() const;
};
#endif