/** @file Bicicleta.hh
    @brief Especificacion de la clase Bicicleta
*/

#ifndef BICICLETA_HH
#define BICICLETA_HH

#ifndef NO_DIAGRAM
#include <iostream>
#include <vector>
using namespace std;
#endif

class Bicicleta
{
private:
    string id_bici;
    vector<pair<string, string>> viajes;
    string est_actual;

    /** @brief Se actualiza los viajes hechos por el p.i
     * \pre Los strings correspondientes al pair corresponden a estaciones,
     * dichos strings no son los mismos
     * \post Se actualiza el parametro viajes del p.i con el pair
     */
    void actualiza_viajes(const pair<string, string> &viaje);

public:
    // constructora

    /** @brief Constructora vacia
     * \pre Cierto.
     * \post Crea una bicicleta con id y estacion NP, sin viajes
     */
    Bicicleta();

    /** @brief Constructora por defecto
        \pre id_bici no existe, id_estacion corresponde a una Estacion
        \post Se crea una Bicicleta con identificador id_bici, Estacion actual en id_estacion y sin viajes
    */
    Bicicleta(const string &id_bici, const string &id_estacion);

    // modificadores

    /** @brief Actualiza la Estacion donde se encuentra el p.i.
     * \pre id_estacion corresponde a una Estacion diferente a la estacion actual del p.i.
     * \post La bicicleta pasa a estar en id_estacion, se añade el viaje al total del p.i.
     */
    void actualiza_estacion(const string &id_estacion);

    /** @brief Modificadora por defecto
     *  \pre id_bici no corresponde a ninguna Bicicleta, id_estacion corresponde a una estacion
     *  \post Los parametros del p.i se actualizan por los parametros de la funcion
     */
    void modifica_bici(const string &id_bici, const string &id_estacion);

    // Consultores

    /** @brief Consulta estacion
        \pre p.i. inicializado
        \post Devuelve la estacion donde se encuentra del p.i.
    */
    string consulta_estacion() const;

    // Lectura y escritura

    /** @brief Imprime los viajes realizados por el p.i.
        \pre p.i. inicializado
        \post Imprime los viajes realizados por el p.i.
    */
    void imprime_viajes() const;
};
#endif