#include "cjt_estaciones.hh"

cjt_estaciones::cjt_estaciones()
{

    conj_estaciones = map<string, Estacion>();
    bicing = leer_arbol(capacidad_total);
}

bool cjt_estaciones::existe_estacion(const string &estacion) const
{
    return conj_estaciones.find(estacion) != conj_estaciones.end();
}

Estacion cjt_estaciones::consulta_estacion(const string id)
{
    return conj_estaciones[id];
}

BinTree<string> cjt_estaciones::leer_arbol(int &capacidad)
{
    string id_est;
    int max_bicis;

    cin >> id_est;

    if (id_est == "#")
        return BinTree<string>();
    else
    {
        cin >> max_bicis;
        capacidad += max_bicis;
        Estacion estacion(max_bicis, id_est);
        conj_estaciones.insert(make_pair(id_est, estacion));
        BinTree<string> izq = leer_arbol(capacidad);
        BinTree<string> der = leer_arbol(capacidad);
        return BinTree<string>(id_est, izq, der);
    }
}

int cjt_estaciones::consulta_capacidad_general() const
{
    return capacidad_total;
}

void cjt_estaciones::actualizar_valor_map_estacion(const string &id_estacion, const Estacion &e)
{
    map<string, Estacion>::iterator it = conj_estaciones.find(id_estacion);
    it->second = e;
}

BinTree<string> cjt_estaciones::consultar_arbol() const
{
    return bicing;
}

void cjt_estaciones::modifica_capacidad_total(int num)
{
    capacidad_total += num;
}

void cjt_estaciones::coef_des(const BinTree<string> &b, double &c, Estacion &r)
{
    double res = 0;
    if (not b.empty())
    {
        if (not b.left().empty())
            coef_des(b.left(), c, r);

        if (not b.right().empty())
            coef_des(b.right(), c, r);

        Estacion auxe = consulta_estacion(b.value());
        int a = auxe.max_estacion() - auxe.total_bicis();

        if (b.left().empty()) // hoja
        {
            auxe.modifica_nodos_plazas(a, 1);
            actualizar_valor_map_estacion(b.value(), auxe);
            res = a;
        }
        else
        {
            Estacion left = consulta_estacion(b.left().value());
            Estacion right = consulta_estacion(b.right().value());
            double nodos = right.consultar_nodos_plazas().second + left.consultar_nodos_plazas().second + 1;
            int plazas = right.consultar_nodos_plazas().first + left.consultar_nodos_plazas().first + a;
            auxe.modifica_nodos_plazas(plazas, nodos);
            actualizar_valor_map_estacion(b.value(), auxe);
            res = plazas / nodos;
        }

        if (res > c)
        {
            c = res;
            r = consulta_estacion(b.value());
        }
        else if (res == c)
        {
            if (b.value() < r.identificador_estacion())
            {
                c = res;
                r = consulta_estacion(b.value());
            }
        }
    }
}