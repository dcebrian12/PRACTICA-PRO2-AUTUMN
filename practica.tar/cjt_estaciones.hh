/** @file cjt_estaciones.hh
    @brief Especificacion de la clase cjt_estaciones
*/

#ifndef CJT_ESTACIONES_HH
#define CJT_ESTACIONES_HH

#ifndef NO_DIAGRAM
#include <iostream>
#include <map>
#include "BinTree.hh"
#endif

#include "Estacion.hh"

using namespace std;

class cjt_estaciones
{
private:
    map<string, Estacion> conj_estaciones;
    BinTree<string> bicing;
    int capacidad_total;

    /** @brief Leer un bintree en preorden
     *  \pre Cierto.
     * \post Devuelve el BinTree correspondiente, establece la capacidad total
     */
    BinTree<string> leer_arbol(int &capacidad);

public:
    // Constructores

    /** @brief Constructora por defecto
     * \pre Cierto.
     * \post Devuelve un cjt_estaciones con map vacio, lee un bintree en preorden
     */
    cjt_estaciones();

    // Modificadores

    /** @brief Actualiza el valor de la capacidad total del conjunto de estaciones
     * \pre Cierto.
     * \post capacidad_total += num
     */
    void modifica_capacidad_total(int num);

    /** @brief Actualiza la estacion guardada en el map con valor id_estacion
     *  \pre id_estacion pertenece a una estacion
     *  \post El valor del map con clave id_estacion se actualiza por e
     */
    void actualizar_valor_map_estacion(const string &id_estacion, const Estacion &e);

    // Consultores

    /** @brief Encuentra la Estacion con el coeficiente de desocupacion mayor
     * \pre c <= 0
     * \post Calcula la Estacion con coeficiente de desocupacion mayor, en caso que haya dos con el mismo la Estacion es
     * la que tiene el id menor. Deja en c dicho coeficiente. Deja dicha Estacion en r
     */
    void coef_des(const BinTree<string> &b, double &c, Estacion &r);

    /** @brief Devuelve el arbol del parametro implicito
     * \pre Cierto.
     * \post Devuelve el BinTree del p.i.
     */
    BinTree<string> consultar_arbol() const;

    /** @brief Devuelve la Estacion asignada a id
     * \pre id corresponde a una Estacion
     * \post Devuelve la Estacion correspondiente al id
     */
    Estacion consulta_estacion(const string id);

    /** @brief Consulta si existe la Estacion
     * \pre Cierto.
     * \post Devuelve true si existe la Estacion
     */
    bool existe_estacion(const string &estacion) const;

    /** @brief Devuelve el numero total de plazas libres
     * \pre Cierto.
     * \post Devuelve el total de plazas libres
     */
    int consulta_capacidad_general() const;

    // Lectura y escritura
};
#endif