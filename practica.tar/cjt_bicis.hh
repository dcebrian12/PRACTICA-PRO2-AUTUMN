/** @file cjt_bicis.hh
    @brief Especificacion de la clase cjt_bicis
*/

#ifndef CJT_BICIS_HH
#define CJT_BICIS_HH

#ifndef NO_DIAGRAM
#include <iostream>
#include <map>
#include "BinTree.hh"
using namespace std;
#endif

#include "Bicicleta.hh"
#include "cjt_estaciones.hh"

class cjt_bicis
{
private:
    map<string, Bicicleta> total_bicis;

    /** @brief La Estacion de id_bici pasa a ser id_estacion sin contar el viaje
     *  \pre id_bici pertenece a una Bicicleta,
     *  id_estacion pertenece a una Estacion diferente a la que esta id_bici
     * \post La Estacion actual de id_bici es id_estacion, el viaje no cuenta
     */
    static void subir_bicis(const string id_bici, Estacion &antigua, Estacion &nueva, cjt_estaciones &e, cjt_bicis &b);

public:
    // Constructores

    /** @brief Constructora por defecto
     * \pre Cierto.
     * \post Ee crea un cjt_bicis con map vacio
     */
    cjt_bicis();

    // Modificadores

    /** @brief La estacion de id_bici pasa a ser id_estacion
     *  \pre id_bici pertenece a una Bicicleta,
     *  id_estacion pertenece a una estacion diferente a la que esta id_bici
     * \post La Estacion actual de id_bici es id_estacion
     */
    void cambiar_de_estacion(const string id_bici, const string id_estacion, cjt_estaciones &e);

    /** @brief Dar de alta una bici
     *  \pre Bici no existe, id_estacion existe
     *  \post Bici pasa a estar en la estacion determinada por id_estacion, se decrementa la capacidad_total
     */
    void alta_bici(const string bici, const string id_estacion, cjt_estaciones &e);

    /** @brief Dar de baja una bici
     *  \pre id_bici existe
     *  \post id_bici desaparece del sistema; se decrementa el numero total de bicis, id_bici desaparece de su estacion correspondiente
     */
    void baja_bici(const string id_bici, cjt_estaciones &e);

    /** @brief Actualiza la Bicicleta guardada en el map con valor id_bici
     *  \pre id_bici pertenece a una Bicicleta
     *  \post El valor del map con clave id_bici se actualiza por b
     */
    void actualizar_valor_map_bicicleta(string id_bici, Bicicleta &b);

    /** @brief Mueve las bicis hacia la primera opcion
     * \pre Cierto.
     * \post Llena cada Estacion con Bicicletas de sus predecesoras de la manera mas equlibriada posible.
     *  La Estacion queda lo mas llena posible, las dos estaciones siguientes quedan lo mas vacias posible
     */
    void reestructurar_ubicacion(cjt_estaciones &e, const BinTree<string> &c, cjt_bicis &b);

    // Consultores

    /** @brief Devuelve la Bicicleta correspondiente al id
     *  \pre id pertenece a una Bicicleta
     *  \post Devuelve la Bicicleta asociada a id
     */
    Bicicleta devuelve_bicicleta(const string &id);

    /** @brief Consulta si existe la Bicicleta
     * \pre Cierto.
     * \post Devuelve true si existe la Bicicleta
     */
    bool existe_bici(const string &bicicleta) const;

    // Lectura y escritura
    /** @brief Imprime el id de la estacion correspondiente al id_bici
     *  \pre id_bici corresponde a una Bicicleta
     *  \post Imprime el id de la estacion asociada al identificador de la bici
     */
    void imprime_estacion(const string &id_bici);
};
#endif